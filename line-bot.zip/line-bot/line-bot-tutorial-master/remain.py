    # if event.message.text == "吃哪裡":
    #     buttons_template = TemplateSendMessage(
    #         alt_text='吃哪裡 template',
    #         template=ButtonsTemplate(
    #             title='吃哪裡',
    #             text='吃哪裡',
    #             thumbnail_image_url='https://storage.googleapis.com/www-cw-com-tw/article/202004/article-5e9041bbd6b2d.jpg',
    #             actions=[
    #                 MessageTemplateAction(
    #                     label='本部',
    #                     text='本部'
    #                 ),
    #                 MessageTemplateAction(
    #                     label='南大',
    #                     text='南大'
    #                 )
    #             ]
    #         )
    #     )
    #     line_bot_api.reply_message(event.reply_token, buttons_template)
    #     return 0

    # if event.message.text == "本部":
    #     buttons_template = TemplateSendMessage(
    #         alt_text='本部 template',
    #         template=ButtonsTemplate(
    #             title='怎麼選',
    #             text='怎麼選',
    #             thumbnail_image_url='https://storage.googleapis.com/www-cw-com-tw/article/202004/article-5e9041bbd6b2d.jpg',
    #             actions=[
    #                 MessageTemplateAction(
    #                     label='隨便(本部)',
    #                     text='隨便(本部)'
    #                 ),
    #                 MessageTemplateAction(
    #                     label='距離(本部)',
    #                     text='距離(本部)'
    #                 ),
    #                 MessageTemplateAction(
    #                     label='價錢(本部)',
    #                     text='價錢(本部)'
    #                 )
    #             ]
    #         )
    #     )
    #     line_bot_api.reply_message(event.reply_token, buttons_template)
    #     return 0
    # if event.message.text == "南大":
    #     buttons_template = TemplateSendMessage(
    #         alt_text='南大 template',
    #         template=ButtonsTemplate(
    #             title='怎麼選',
    #             text='怎麼選',
    #             thumbnail_image_url='https://storage.googleapis.com/www-cw-com-tw/article/202004/article-5e9041bbd6b2d.jpg',
    #             actions=[
    #                 MessageTemplateAction(
    #                     label='隨便(南大)',
    #                     text='隨便(南大)'
    #                 ),
    #                 MessageTemplateAction(
    #                     label='距離(南大)',
    #                     text='距離(南大)'
    #                 ),
    #                 MessageTemplateAction(
    #                     label='價錢(南大)',
    #                     text='價錢(南大)'
    #                 )
    #             ]
    #         )
    #     )
    #     line_bot_api.reply_message(event.reply_token, buttons_template)
    #     return 0

    # if event.message.text == "隨便(本部)":
    #     randomNumber = random.randint(1, 1)
    #     if randomNumber == 1:
    #         buttons_template = TemplateSendMessage(
    #             alt_text='隨便 template',
    #             template=ButtonsTemplate(
    #                 title='港島主麵',
    #                 text='港島主麵',
    #                 thumbnail_image_url='https://imgur.com/bE8jSLY.png',
    #                 actions=[
    #                     URIAction(
    #                         label='Google地圖',
    #                         uri='https://goo.gl/maps/JzWyX7nJ3w82NeEm6'
    #                     ),
    #                     URIAction(
    #                         label='FOODPANDA',
    #                         uri='https://www.foodpanda.com.tw/zh/restaurant/new/i7mb/zhu-mian-xin-zhu-qing-da-dian?utm_campaign=google_reserve_place_order_action&utm_medium=organic&utm_source=google'
    #                     )
    #                 ]
    #             )
    #         )
    #     line_bot_api.reply_message(event.reply_token, buttons_template)
    #     return 0


#         @handler.add(MessageEvent, message=TextMessage)
# def handle_message(event):
#     # event.message.text是用戶傳來的文字訊息
#     import random
#     data = random.choice(["牛肉麵", "炒飯", "早餐店"])
#     message = TextSendMessage(text=data)
#     line_bot_api.reply_message(event.reply_token, message

    # if event.message.text == "本部":
    #     carousel_template_message = TemplateSendMessage(
    #         alt_text='本部 template',
    #         template=CarouselTemplate(
    #             columns=[
    #                 CarouselColumn(
    #                     thumbnail_image_url='https://i.imgur.com/kzi5kKy.jpg',
    #                     title='你就隨便挑吧(本部)',
    #                     text='不喜歡的話怪我囉?',
    #                     actions=[
    #                         MessageAction(
    #                             label='GOGO!(本部)',
    #                             text='GOGO!(本部)'
    #                         )
    #                     ]
    #                 ),
    #                 CarouselColumn(
    #                     thumbnail_image_url='https://i.imgur.com/DrsmtKS.jpg',
    #                     title='用距離選(本部)',
    #                     text='看距離',
    #                     actions=[
    #                         MessageAction(
    #                             label='遠(本部)',
    #                             text='遠(本部)'
    #                         ),
    #                         MessageAction(
    #                             label='中(本部)',
    #                             text='中(本部)'
    #                         ),
    #                         MessageAction(
    #                             label='近(本部)',
    #                             text='近(本部)'
    #                         )
    #                     ]
    #                 ),
    #                 CarouselColumn(
    #                     thumbnail_image_url='https://i.imgur.com/h4UzRit.jpg',
    #                     title='用價錢選(本部)',
    #                     text='看價錢',
    #                     actions=[
    #                         MessageAction(
    #                             label='便宜(本部)',
    #                             text='便宜(本部)'
    #                         ),
    #                         MessageAction(
    #                             label='尚可(本部)',
    #                             text='尚可(本部)'
    #                         ),
    #                         MessageAction(
    #                             label='貴(本部)',
    #                             text='貴(本部)'
    #                         )
    #                     ]
    #                 )
    #             ]
    #         )
    #     )
    #     line_bot_api.reply_message(
    #         event.reply_token, carousel_template_message)
    # if event.message.text == "南大":
    #     carousel_template_message = TemplateSendMessage(
    #         alt_text='南大 template',
    #         template=CarouselTemplate(
    #             columns=[
    #                 CarouselColumn(
    #                     thumbnail_image_url='https://i.imgur.com/kzi5kKy.jpg',
    #                     title='你就隨便挑吧(南大)',
    #                     text='不喜歡的話怪我囉?',
    #                     actions=[
    #                         MessageAction(
    #                             label='GOGO!(南大)',
    #                             text='GOGO!(南大)'
    #                         )
    #                     ]
    #                 ),
    #                 CarouselColumn(
    #                     thumbnail_image_url='https://i.imgur.com/DrsmtKS.jpg',
    #                     title='用距離選(南大)',
    #                     text='看距離',
    #                     actions=[
    #                         MessageAction(
    #                             label='遠(南大)',
    #                             text='遠(南大)'
    #                         ),
    #                         MessageAction(
    #                             label='中(南大)',
    #                             text='中(南大)'
    #                         ),
    #                         MessageAction(
    #                             label='近(南大)',
    #                             text='近(南大)'
    #                         )
    #                     ]
    #                 ),
    #                 CarouselColumn(
    #                     thumbnail_image_url='https://i.imgur.com/h4UzRit.jpg',
    #                     title='用價錢選(南大)',
    #                     text='看價錢',
    #                     actions=[
    #                         MessageAction(
    #                             label='便宜(南大)',
    #                             text='便宜(南大)'
    #                         ),
    #                         MessageAction(
    #                             label='尚可(南大)',
    #                             text='尚可(南大)'
    #                         ),
    #                         MessageAction(
    #                             label='貴(南大)',
    #                             text='貴(南大)'
    #                         )
    #                     ]
    #                 )
    #             ]
    #         )
    #     )
    #     line_bot_api.reply_message(
    #         event.reply_token, carousel_template_message)