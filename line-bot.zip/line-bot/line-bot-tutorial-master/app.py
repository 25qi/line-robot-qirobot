# from __future__ import unicode_literals
import os
from flask import Flask, request, abort

from linebot import (
    LineBotApi, WebhookHandler
)
from linebot.exceptions import (
    InvalidSignatureError
)
from linebot.models import *
import random

app = Flask(__name__)

# Channel Access Token
line_bot_api = LineBotApi(
    'MLc1aUiwxBWfs5E+jjClobOYQ1e03z/+fREZ+fSaotYlWh7qgz13BfOVKVC/oCkxbOlNEGfidZSBMEpDm7do5G6CXpROpvtpyScKYVXWUQ06X+VwGSojKmlNwkfctw4LqGpY7dAfO1beUFmfs1cJtAdB04t89/1O/w1cDnyilFU=')
# Channel Secret
handler = WebhookHandler('3dff318d1e5e31ca30a2864b12f9e0e7')

# 監聽所有來自 /callback 的 Post Request
# 接收所有line資訊


@app.route("/callback", methods=['POST'])
def callback():
    # get X-Line-Signature header value
    signature = request.headers['X-Line-Signature']
    # get request body as text
    body = request.get_data(as_text=True)
    app.logger.info("Request body: " + body)
    # handle webhook body
    try:
        handler.handle(body, signature)
    except InvalidSignatureError:
        abort(400)
    return 'OK'


def pattern_mega(text):
    patterns = [
        'mega', 'mg', 'mu', 'ＭＥＧＡ', 'ＭＥ', 'ＭＵ',
        'ｍｅ', 'ｍｕ', 'ｍｅｇａ', 'GD', 'MG', 'google',
    ]
    for pattern in patterns:
        if re.search(pattern, text, re.IGNORECASE):
            return True


@handler.add(MessageEvent, message=TextMessage)
def handle_message(event):
    print("event.reply_token:", event.reply_token)
    print("event.message.text:", event.message.text)
    people = random.choice(["以諾", "黃琦", "紹宇"])
    P = str(people+"傳送了美食資訊")
    if event.message.text == "食途幫我決定今天吃什麼！" or "再抽一次":
        randomNumber = random.randint(1, 10)
        if randomNumber == 1:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='港島主麵',
                    text='港島主麵',
                    thumbnail_image_url='https://imgur.com/bE8jSLY.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/JzWyX7nJ3w82NeEm6'
                        ),
                        URIAction(
                            label='FOODPANDA',
                            uri='https://www.foodpanda.com.tw/zh/restaurant/new/i7mb/zhu-mian-xin-zhu-qing-da-dian?utm_campaign=google_reserve_place_order_action&utm_medium=organic&utm_source=google'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 2:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='義早早午餐-新竹建功店',
                    text='義早早午餐-新竹建功店',
                    thumbnail_image_url='https://imgur.com/gVF9HWN.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://g.page/Hsinchubrunch?share'
                        ),
                        URIAction(
                            label='FOODPANDA',
                            uri='https://www.foodpanda.com.tw/zh/restaurant/new/z6xh/yi-zao-zao-wu-can-xin-zhu-jian-gong-dian'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 3:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='杜蘭小麥 - 義大利麵.披薩',
                    text='杜蘭小麥 - 義大利麵.披薩',
                    thumbnail_image_url='https://imgur.com/Dq56Zwn.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/Wwz5uHyk57MLg9MCA'
                        ),
                        URIAction(
                            label='ubereats',
                            uri='https://www.ubereats.com/tw/store/杜蘭小麥-清大店/6cXxDGvsSLa_2eLscaeBGA?utm_source=google&utm_medium=organic&utm_campaign=place-action-link'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 4:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='白鬍子厚切牛排',
                    text='白鬍子厚切牛排',
                    thumbnail_image_url='：https://imgur.com/undefined.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/fBqNf5Uf6ut7YhLy8'
                        ),
                        URIAction(
                            label='FOODPANDA',
                            uri='https://www.foodpanda.com.tw/zh/restaurant/new/r0oa/bai-hu-zi-hou-qie-niu-pai-zhong-li-chang-chun-dian'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 5:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='紅吱吱牛排館',
                    text='紅吱吱牛排館',
                    thumbnail_image_url='https://imgur.com/ns5ndM3.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/izhvxUA7vwQJtjQ99'
                        ),
                        URIAction(
                            label='FOODPANDA',
                            uri='https://www.foodpanda.com.tw/zh/restaurant/new/s3te/hong-zhi-zhi-niu-pai-xin-zhu-guang-fu-dian'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 6:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='大埔鐵板燒',
                    text='大埔鐵板燒',
                    thumbnail_image_url='https://imgur.com/cFWlUtx.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/BDuNnh7PiVvDFaK79'
                        ),
                        URIAction(
                            label='FOODPANDA',
                            uri='https://www.foodpanda.com.tw/zh/restaurant/new/i7mb/zhu-mian-xin-zhu-qing-da-dian?utm_campaign=google_reserve_place_order_action&utm_medium=organic&utm_source=google'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 7:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='六扇門時尚湯鍋 新竹建功店',
                    text='六扇門時尚湯鍋 新竹建功店',
                    thumbnail_image_url='https://imgur.com/GBzZMwW.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/9opES9Uqeh1XW1cc8'
                        ),
                        URIAction(
                            label='FOODPANDA',
                            uri='https://www.foodpanda.com.tw/zh/restaurant/new/a1ow/liu-shan-men-xin-zhu-qing-da-dian'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 8:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='哈奇客Hot Chicken韓式炸雞',
                    text='哈奇客Hot Chicken韓式炸雞',
                    thumbnail_image_url='https://imgur.com/undefined.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://g.page/h0t-ch1cken?share'
                        ),
                        URIAction(
                            label='FOODPANDA',
                            uri='https://www.foodpanda.com.tw/zh/restaurant/new/y5lh/ha-qi-ke-han-shi-zha-ji-xin-zhu-qing-da-dian'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 9:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='立晉傳統豆花',
                    text='立晉傳統豆花',
                    thumbnail_image_url='https://imgur.com/6NYJo5x.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/BDuNnh7PiVvDFaK79'
                        ),
                        URIAction(
                            label='FOODPANDA',
                            uri='https://www.foodpanda.com.tw/zh/restaurant/new/i7mb/zhu-mian-xin-zhu-qing-da-dian?utm_campaign=google_reserve_place_order_action&utm_medium=organic&utm_source=google'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 10:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='永記牛肉麵',
                    text='永記牛肉麵',
                    thumbnail_image_url='https://imgur.com/dzPuY5Z.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/bc2fqv2hVDU4Kt8B7'
                        ),
                        URIAction(
                            label='FOODPANDA',
                            uri='https://www.ubereats.com/tw/store/永記牛肉麵/rm-jtmVmTzWFfPLwZqhcYA?utm_source=google&utm_medium=organic&utm_campaign=place-action-link'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 11:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='新竹鴨香意麵',
                    text='新竹鴨香意麵',
                    thumbnail_image_url='https://imgur.com/CECccpJ.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/tN7sn2pxscDcZ1V36'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 12:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='重慶酸辣粉新竹清大店',
                    text='重慶酸辣粉新竹清大店',
                    thumbnail_image_url='https://imgur.com/i0Qk9y4.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/k5W5dKctSisM3psL6'
                        ),
                        URIAction(
                            label='FOODPANDA',
                            uri='https://www.ubereats.com/tw/store/重慶酸辣粉-新竹清大店/SoOHeJlxS4e7Fx0oehBcxQ?utm_source=google&utm_medium=organic&utm_campaign=place-action-link'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 13:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='日荃蒸餃',
                    text='日荃蒸餃',
                    thumbnail_image_url='https://imgur.com/0iyRYWi.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/PtfSXrAwwBMrKXEc6'
                        ),
                        URIAction(
                            label='FOODPANDA',
                            uri='https://www.foodpanda.com.tw/zh/restaurant/new/y5an/ri-quan-zheng-jiao?utm_campaign=google_reserve_place_order_action&utm_medium=organic&utm_source=google'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 14:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='永記牛肉麵',
                    text='永記牛肉麵',
                    thumbnail_image_url='https://imgur.com/dzPuY5Z.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/bc2fqv2hVDU4Kt8B7'
                        ),
                        URIAction(
                            label='FOODPANDA',
                            uri='https://www.ubereats.com/tw/store/永記牛肉麵/rm-jtmVmTzWFfPLwZqhcYA?utm_source=google&utm_medium=organic&utm_campaign=place-action-link'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 15:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='來來豆漿',
                    text='來來豆漿',
                    thumbnail_image_url='https://imgur.com/F3itk6X.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/kG3NTPAwBPLARWrJ9'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )
        if randomNumber == 16:
            buttons_template = TemplateSendMessage(
                alt_text=P,
                template=ButtonsTemplate(
                    title='建新水煎包',
                    text='建新水煎包',
                    thumbnail_image_url='https://imgur.com/ZDWpE9Z.png',
                    actions=[
                        URIAction(
                            label='Google地圖',
                            uri='https://goo.gl/maps/xQFNoDKsiWAGoYsAA'
                        ),
                        MessageTemplateAction(
                            label='再抽一次',
                            text='再抽一次'
                        )
                    ]
                )
            )

        line_bot_api.reply_message(event.reply_token, buttons_template)
        return 0


# 處理訊息
# @handler.add(MessageEvent, message=TextMessage)
# def handle_message(event):
# line_bot_api.reply_message(event.reply_token, TextSendMessage(text="你也太好笑了吧"+event.message.text+"???"))
if __name__ == "__main__":
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
